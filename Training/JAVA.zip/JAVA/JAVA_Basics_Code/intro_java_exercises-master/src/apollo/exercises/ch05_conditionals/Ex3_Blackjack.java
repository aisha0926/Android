package apollo.exercises.ch05_conditionals;

public class Ex3_Blackjack {

	// This is the main method that is executed as
	// soon as the program starts.	
	public static void main(String[] args) {
		
		// Given 2 int values greater than 0, return whichever 
		// value is nearest to 21 without going over. 
		// Return 0 if they both go over. 
		//
		
		// Call the method a few times and print the results
	}
	
	// Create a method like:
	//   public int blackjack(int a, int b)
	//

}

/*
 * SAMPLE OUTPUT:
 * 
 * 6
 * 8
 * 0
 * 
 */