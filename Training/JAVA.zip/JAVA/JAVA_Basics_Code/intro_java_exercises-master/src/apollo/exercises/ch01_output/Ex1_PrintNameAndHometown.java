package apollo.exercises.ch01_output;

// This is a program that prints your name and hometown.
public class Ex1_PrintNameAndHometown {

	// This is the main method that is executed as
	// soon as the program starts.
	public static void main(String[] args) {
		
		// Print your name and hometown on separate lines.
		//
		// After running the program, you should see something like
		// this in the console: http://d.pr/i/7LO9
		//
		
	}
	
}

/*
 * SAMPLE OUTPUT:
 *  
 *   Billy Joe
 *   Cleveland, OH
 *   
 */
