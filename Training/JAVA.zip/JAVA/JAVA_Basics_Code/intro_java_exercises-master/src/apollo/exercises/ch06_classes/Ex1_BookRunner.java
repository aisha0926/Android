package apollo.exercises.ch06_classes;

public class Ex1_BookRunner {

	// This is the main method that is executed as
	// soon as the program starts.	
	public static void main(String[] args) {

	}

}
