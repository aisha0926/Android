package apollo.exercises.ch08_collections;

public class Ex4_RemoveOdd {

	// This is the main method that is executed as
	// soon as the program starts.	
	public static void main(String[] args) {
		
		// Create a method called removeOdd
		// Remove all the odd numbers from an ArrayList 

		// removeOdd(Arrays.asList(1,2,3,5,8,13,21)) => {2, 8}
		// removeOdd(Arrays.asList(7,34,2,3,4,62,3)) => {34, 2, 4, 62}
		
	}

}
