package apollo.exercises.ch08_collections;

public class Ex1_BasicArrayList {

	// This is the main method that is executed as
	// soon as the program starts.
	public static void main(String[] args) {
		
		// Directions:
		//
		// 1) Declare am ArrayList of strings
		// 2) Call the add method and add 10 random strings
		// 3) Iterate through all the elements in the ArrayList
		// 4) Remove the first and last element of the ArrayList
		// 5) Iterate through all the elements in the ArrayList, again.

	}

}
