package apollo.exercises.ch04_loops;

// This is a number that prints out sequential, descending numbers
public class Ex2_CountingBackwards {

	// This is the main method that is executed as
	// soon as the program starts.
	public static void main(String[] args) {
		
		// Print out the numbers 100, 99, 98, ..., 3, 2, 1
		// Use a for loop.
		
	}

}


/*
 * SAMPLE OUTPUT:
 *  
 *  100
 *  99
 *  98
 *  99
 *  97
 *  ...
 *  3
 *  2
 *  1
 *   
 */