package apollo.exercises.ch01_output;

// This is a program that prints a fun fact about yourself.
public class Ex2_PrintFunFact {

	// This is the main method that is executed as
	// soon as the program starts.
	public static void main(String[] args) {

		// Print two separate facts about yourself on different lines with a single println statement.
		// HINT: Use println and then add a "\n" within quotes to force a new line.
		// i.e "This is one line\nThis is the next"
		
	}

}

/*
 * SAMPLE OUTPUT:
 *  
 *   I like to go rock climbing.
 *   I used to live in Brazil.
 *   
 */