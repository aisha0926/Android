package apollo.exercises.ch08_collections;

import java.util.HashMap;

public class Ex3_NamesAndAddresses {

	// This is the main method that is executed as
	// soon as the program starts.
	public static void main(String[] args) {
		
		// Create a method called printAddress(HashMap book, String name)
		//
		// HashMap book = new HashMap();
		// map.put("Mike", "123 2nd Street, SF, CA 94105");
		// map.put("Bob", "333 Folsom Street, SF, CA 94107");
		// map.put("Joe", "45 King Street, SF, CA 94158");
		//
		// printAddress(book, "Mike");
		
	}

}
