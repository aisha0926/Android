
public interface MyInterface {
	 /* All the methods are public abstract by default
	    * Note down that these methods are not having body
	    */
	
	/*variables declared in interface because by default, they are public, static and final. */
//	int x;//Compile-time error  
	int x=0;
	public void method1();
	   public void method2();
}
