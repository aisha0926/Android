package main.java.music;

abstract class Instrument {
	protected String name;
	
	abstract public void play();
}
