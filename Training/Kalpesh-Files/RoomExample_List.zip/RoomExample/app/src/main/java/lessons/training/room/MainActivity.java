package lessons.training.room;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import lessons.training.room.database.AppDatabase;
import lessons.training.room.entities.Person;
import lessons.training.room.util.AppExecutors;

public class MainActivity extends AppCompatActivity {

    EditText name, email, pincode, city, phone;
    Button save;
    private AppDatabase mDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
        initializeUI();
    }

    public void initializeUI(){
        name =  findViewById(R.id.edit_name);
        email =  findViewById(R.id.edit_email);
        pincode =  findViewById(R.id.edit_pincode);
        city =  findViewById(R.id.edit_city);
        phone =  findViewById(R.id.edit_number);
        save  = findViewById(R.id.button);

    }

    public void initializeDatabase(){
        mDB =AppDatabase.getInstance(getApplicationContext());
    }

    @Override
    protected void onResume() {
        super.onResume();
        initializeDatabase();

    }

    public void savePersonData(View view ){
        final Person person = new Person(
                name.getText().toString(),
                email.getText().toString(),
                phone.getText().toString(),
                pincode.getText().toString(),
                city.getText().toString()
        );

        /**
         * perform save operation in separate
         */
        AppExecutors.getInstance().diskIO().execute(new Runnable() {
            @Override
            public void run() {
                try {
                    mDB.iPersonDAO().insertPerson(person);
                }
                catch (Exception e){
                    Log.e("ErrorDatabase", e.getLocalizedMessage());
                }
            }
        });


            Intent intent = new Intent(MainActivity.this, RecyclerviewDemo.class);
            startActivity(intent);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
                mDB.close();

    }

    //    @Override
//    protected void onDestory() {
//        super.onDestory();
//        mDB.close();
//    }
}