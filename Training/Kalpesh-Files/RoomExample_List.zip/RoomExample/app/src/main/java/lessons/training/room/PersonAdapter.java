package lessons.training.room;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import lessons.training.room.entities.Person;


/**
 * Custom Adapter
 * 1 Extend RecyclerView.Adapter
 * 2 Create a viewholder inner class
     *  2.1 RecyclerView.Adapter<PersonAdapter.MyViewHolder>
     *  2.2 Constructor for Viewholder class
 * 3 Override Adapter methods
     *  3.1 onCreateViewHolder
     *  3.2 onBindViewHolder
     *  3.3 getItemCount
 * 4 Finishing the viewholder implementation
 * 5 onCreateViewHolder== inflating the row
 * 6 getItemCount = number of elements to display in the list
 * 7 onBindViewHolder = // bind view (data)
 * 8 In the function called ; use notifyDataSetChanged();
 */
public class PersonAdapter extends RecyclerView.Adapter<PersonAdapter.MyViewHolder> {

    private List<Person> personList;
    private Context mContext;
    public PersonAdapter(Context context) {
        /**
         * This passed from the activity when we initialze the adapter
         */
        this.mContext= context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.row_person, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
    // bind view (data)
        holder.name.setText(personList.get(position).getName());
        holder.email.setText(personList.get(position).getEmail());
        holder.phone.setText(personList.get(position).getNumber());

    }

    @Override
    public int getItemCount() {
        if(personList==null) {
            return 0;
        }
        return personList.size() ;
    }

    public void setPersonDataInAdapter(List<Person> mPersonList) {
        personList = mPersonList;
        notifyDataSetChanged();
    }

    /**
     * Caching view references== row
     */
    class MyViewHolder extends RecyclerView.ViewHolder{
        TextView name, email, phone;
        ImageView image;
         public MyViewHolder(@NonNull View itemView) {
             super(itemView);

             name = itemView.findViewById(R.id.tvName);
             email = itemView.findViewById(R.id.tvEmail);
             phone = itemView.findViewById(R.id.tvPhone);
             image = itemView.findViewById(R.id.imgView);

         }
     }
}
