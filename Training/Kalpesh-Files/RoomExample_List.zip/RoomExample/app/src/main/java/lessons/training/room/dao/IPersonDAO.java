package lessons.training.room.dao;


import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import lessons.training.room.entities.Order;
import lessons.training.room.entities.Person;

@Dao
public interface IPersonDAO {

    // queries: CRUD
/**
     * INSERT INTO table_name
     * VALUES (value1, value2, value3, ...);
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertPerson(Person person);


    @Query("SELECT * FROM PERSON ORDER BY ID")
    List<Person> loadAllPerson();


    @Update
    void updatePerson(Person person);


    @Delete
    void delete(Person person);


}
