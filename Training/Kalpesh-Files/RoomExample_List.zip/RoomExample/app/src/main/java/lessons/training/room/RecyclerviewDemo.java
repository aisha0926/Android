package lessons.training.room;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.List;

import lessons.training.room.database.AppDatabase;
import lessons.training.room.entities.Person;
import lessons.training.room.util.AppExecutors;

public class RecyclerviewDemo extends AppCompatActivity {
// 1 Model
    // 2 Adapter
    // 3 View
    private AppDatabase mDB;
    private RecyclerView mRecyclerView;
    private PersonAdapter personAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recyclerview_demo);

        // TODO 1: Initialize Database
        mDB= AppDatabase.getInstance(getApplicationContext());

        // TODO 2: Initialize Recyclerview
        mRecyclerView =  findViewById(R.id.rcvPerson);
        // 2.1 Layout
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
//mRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        // TODO 3: Bind the custom adapter
        // 2.2 Adapter
        personAdapter = new PersonAdapter(this);
  mRecyclerView.setAdapter(personAdapter);

        // TODO 5: Call function
        retrievePersonListFromDatabase();



    }

    public void retrievePersonListFromDatabase(){
        // TODO 4: Call worker thread to get the data and pass to adapter
        AppExecutors.getInstance().diskIO().execute(new Runnable() {
            @Override
            public void run() {
                // separate
                final List<Person> personList = mDB.iPersonDAO().loadAllPerson();

                runOnUiThread(new Runnable() {
                    //Main UI
                    @Override
                    public void run() {
                        personAdapter.setPersonDataInAdapter(personList);
                    }
                });

            }
        });
    }
}