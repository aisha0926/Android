package lessons.training.room.entities;

import androidx.room.Entity;

@Entity(tableName = "order")
public class Order {
    String name;

}
