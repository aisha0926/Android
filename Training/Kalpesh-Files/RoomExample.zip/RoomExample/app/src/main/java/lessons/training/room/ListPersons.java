
package lessons.training.room;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ListActivity;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;

import java.util.ArrayList;
import java.util.List;

import lessons.training.room.database.AppDatabase;
import lessons.training.room.entities.Person;
import lessons.training.room.util.AppExecutors;

public class ListPersons extends ListActivity {

    private AppDatabase mDB;
    List<Person> personList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // setContentView(R.layout.activity_list_persons);
        initializeDatabase();
        retrieveTask();
    }
    public void initializeDatabase(){
        mDB =AppDatabase.getInstance(getApplicationContext());
    }


    private void retrieveTask(){
        /**
         * Query it off the main thread
         */

        AppExecutors.getInstance().diskIO().execute(new Runnable() {
            @Override
            public void run() {
                personList = mDB.iPersonDAO().loadAllPerson();
                final List<String> list = new ArrayList<>();
                for(int i =0; i<personList.size(); i++)
                    list.add(personList.get(i).getName());

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(
                                ListPersons.this,
                                R.layout.list_item,
                                R.id.textview,
                                list);
                        ListPersons.this.setListAdapter(arrayAdapter);
                    }
                });
            }


        });
        /**
         * Report result or update UI
         */

    }


    @Override
    protected void onResume() {
        super.onResume();
        initializeDatabase();

    }

    @Override
    protected void onStop() {
        super.onStop();
        mDB.close();
    }
}